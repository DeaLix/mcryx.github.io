const usernameInput = document.getElementById("username");
const playButton = document.getElementById("play-button");
const welcomeScreen = document.getElementById("welcome-screen");
const gameScreen = document.getElementById("game-screen");
const player1 = document.getElementById("player1");
const player2 = document.getElementById("player2");
const ball = document.getElementById("ball");
const ballImage = document.getElementById("ball-image");
const ballSelect = document.getElementById("ball-select");
const goalSound = document.getElementById("goal-sound");
const scoreboard = document.getElementById("scoreboard");
const winnerMessage = document.getElementById("winner-message");
const pauseToggle = document.getElementById("pause-toggle");
const pauseMenu = document.getElementById("pause-menu");
const resumeButton = document.getElementById("resume-button");
const restartButton = document.getElementById("restart-button");
const backButton = document.getElementById("back-button");

let animationId;
let gameState = {
    isPaused: false,
    isWinner: false,
    isExtraTime: false
  };

usernameInput.addEventListener("input", () => {
  const isEmpty = usernameInput.value.trim() === "";
  playButton.disabled = isEmpty;
});

playButton.addEventListener("click", () => {
  const selectedBall = ballSelect.value;
  ballImage.src = `/image/${selectedBall}.png`;
  welcomeScreen.style.display = "none";
  gameScreen.style.display = "block";
  startGame();
});

pauseToggle.addEventListener("click", () => {
  pauseGame();
});

resumeButton.addEventListener("click", () => {
  resumeButton.style.display = "inline-block";
  resumeGame();
});

restartButton.addEventListener("click", () => {
  cancelAnimationFrame(animationId);
  pauseMenu.classList.add("hidden");
  startGame();
});

backButton.addEventListener("click", () => {
  cancelAnimationFrame(animationId);
  gameScreen.style.display = "none";
  welcomeScreen.style.display = "flex";
  pauseMenu.classList.add("hidden");
});

function pauseGame() {
  gameState.isPaused = true;
  pauseMenu.classList.remove("hidden");
}

function resumeGame() {
  gameState.isPaused = false;
  pauseMenu.classList.add("hidden");
  update();
}

function startGame() {
  resumeButton.style.display = "inline-block";

  let player1X = 100, player1Y = 0, velocityY1 = 0, isJumping1 = false;
  let player2X = 850, player2Y = 0, velocityY2 = 0, isJumping2 = false;
  let ballX = 475, ballY = 0, ballDX = 0, ballDY = 0;
  let score1 = 0, score2 = 0;
  const gravity = 0.5;
  const ground = 0;
  const keys = {};
  const gameDuration = 30; // detik
  let timeLeft = gameDuration;
  let timerInterval;

  gameState = { isPaused: false, isWinner: false, isExtraTime: false };

  document.addEventListener("keydown", e => keys[e.key] = true);
  document.addEventListener("keyup", e => keys[e.key] = false);

  function updateScore() {
    let timeText = gameState.isExtraTime ? "EXTRA TIME" : `${timeLeft}s`;
    scoreboard.textContent = `${score1} - ${score2} | Time: ${timeText}`;
  }

  function showGoalPopup() {
    if (gameState.isWinner) return;
    const popup = document.getElementById("goal-popup");
    popup.style.display = "block";
    popup.style.animation = "popGoal 1s ease-out forwards";
    confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 } });
    setTimeout(() => popup.style.display = "none", 2000);
  }

  function declareWinner(winnerText) {
    gameState.isPaused = true;
    gameState.isWinner = true;
    winnerMessage.textContent = winnerText;
    winnerMessage.style.display = "block";
    pauseMenu.classList.remove("hidden");
    pauseMenu.querySelector("h2").textContent = winnerText;
    resumeButton.style.display = "none";
    clearInterval(timerInterval);
  }

  function declareWinnerByScore() {
    if (score1 > score2) declareWinner("Time's Up! Player 1 Wins!");
    else if (score2 > score1) declareWinner("Time's Up! Player 2 Wins!");
    else {
      gameState.isExtraTime = true;
      updateScore();
    }
  }

  function startTimer() {
    timerInterval = setInterval(() => {
      if (!gameState.isPaused && !gameState.isExtraTime) {
        timeLeft--;
        updateScore();
        if (timeLeft <= 0) {
          clearInterval(timerInterval);
          declareWinnerByScore();
        }
      }
    }, 1000);
  }

  function checkGoal() {
    if (ballX <= 0 || ballX >= 950) {
      if (ballX <= 0) score2++;
      else score1++;
      goalSound.play();
      updateScore();
      showGoalPopup();

      if (gameState.isExtraTime) {
        if (score1 !== score2) {
          const winner = score1 > score2 ? "Player 1" : "Player 2";
          declareWinner(`${winner} Wins in Extra Time!`);
        }
      }

      resetBall();
    }
  }

  function resetBall() {
    gameState.isPaused = true;
    ballX = 475;
    ballY = 0;
    ballDX = 0;
    ballDY = 0;
    player1X = 100;
    player1Y = 0;
    player2X = 850;
    player2Y = 0;
    setTimeout(() => gameState.isPaused = false, 2000);
  }

  function update() {
    if (!gameState.isPaused) {
      if (keys["a"]) player1X = Math.max(0, player1X - 5);
      if (keys["d"]) player1X = Math.min(950, player1X + 5);
      if (keys["w"] && !isJumping1) {
        velocityY1 = 10;
        isJumping1 = true;
      }
      player1Y += velocityY1;
      velocityY1 -= gravity;
      if (player1Y <= ground) {
        player1Y = ground;
        isJumping1 = false;
      }

      if (keys["ArrowLeft"]) player2X = Math.max(0, player2X - 5);
      if (keys["ArrowRight"]) player2X = Math.min(950, player2X + 5);
      if (keys["ArrowUp"] && !isJumping2) {
        velocityY2 = 10;
        isJumping2 = true;
      }
      player2Y += velocityY2;
      velocityY2 -= gravity;
      if (player2Y <= ground) {
        player2Y = ground;
        isJumping2 = false;
      }

      const kickPower = 8;
      const dist1 = Math.sqrt((ballX - player1X) ** 2 + (ballY - player1Y) ** 2);
      const dist2 = Math.sqrt((ballX - player2X) ** 2 + (ballY - player2Y) ** 2);

      if (keys[" "] && dist1 < 60) {
        let direction = keys["a"] ? -1 : (keys["d"] ? 1 : 1);
        ballDX = direction * kickPower;
        ballDY = 8;
      }

      if (keys["Enter"] && dist2 < 60) {
        let direction = keys["ArrowLeft"] ? -1 : (keys["ArrowRight"] ? 1 : -1);
        ballDX = direction * kickPower;
        ballDY = 8;
      }

      ballX += ballDX;
      ballY += ballDY;
      ballDY -= gravity;

      if (ballX <= 0 || ballX >= 950) ballDX *= -1;
      if (ballY <= 0) {
        ballY = 0;
        ballDY *= -0.8;
      }
      if (ballY >= 550) {
        ballY = 550;
        ballDY *= -1;
      }

      checkGoal();
    }

    player1.style.left = player1X + "px";
    player1.style.bottom = player1Y + "px";
    player2.style.left = player2X + "px";
    player2.style.bottom = player2Y + "px";
    ball.style.left = ballX + "px";
    ball.style.bottom = ballY + "px";

    animationId = requestAnimationFrame(update);
  }

  updateScore();
  winnerMessage.style.display = "none";
  startTimer();
  update();
}